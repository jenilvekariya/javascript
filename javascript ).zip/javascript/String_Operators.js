let s1 = "jenil";
let s2 = "vekariya";
let s3 = s1 + " " + s2;
document.write(s3);